The manual for Paramotopy is a LaTeX document.  If the pdf is not found in this folder, it must be compiled.  Compilation can be accomplished on virtually any computer, with free software.  

The manual is indexed and contains a bibliography, so a suggested compilation pattern is compile, compile, bib, index, compile, compile.  